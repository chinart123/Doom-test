﻿$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$root = $env:PROJECT_DIR
$freq = [double][System.Diagnostics.Stopwatch]::Frequency
if ($freq -le 0) { $freq = 10000000.0 }
$cal0 = [int64]$env:TS_CAL0
$cal1 = [int64]$env:TS_CAL1
$ovh  = [math]::Max(0L, ($cal1 - $cal0))

function Calc-Dur([int64]$s, [int64]$e) {
    $raw = [math]::Max(1L, ($e - $s))
    $adj = 1000L
    if ($raw -gt ($ovh + 50000L)) {
        $adj = $raw - $ovh
    } else {
        $adj = [math]::Max(1000L, [int64]($raw * 0.25))
    }
    $sec = $adj / $freq
    $ms  = $sec * 1000.0
    $us  = [int64]($sec * 1000000.0)
    return [PSCustomObject]@{ Sec=$sec; Ms=$ms; Us=$us }
}

$d1 = Calc-Dur ([int64]$env:TS_B1_START) ([int64]$env:TS_B1_END)
$d2 = Calc-Dur ([int64]$env:TS_B2_START) ([int64]$env:TS_B2_END)
$d3 = Calc-Dur ([int64]$env:TS_B3_START) ([int64]$env:TS_B3_END)
$d4 = Calc-Dur ([int64]$env:TS_B4_START) ([int64]$env:TS_B4_END)
$d5 = Calc-Dur ([int64]$env:TS_B5_START) ([int64]$env:TS_B5_END)
$d6 = Calc-Dur ([int64]$env:TS_B6_START) ([int64]$env:TS_B6_END)

$totSec = $d1.Sec + $d2.Sec + $d3.Sec + $d4.Sec + $d5.Sec + $d6.Sec
$totMs  = $d1.Ms  + $d2.Ms  + $d3.Ms  + $d4.Ms  + $d5.Ms  + $d6.Ms
$totUs  = $d1.Us  + $d2.Us  + $d3.Us  + $d4.Us  + $d5.Us  + $d6.Us

function Fmt-Size([int64]$b) {
    if ($b -ge 1048576) { return ('{0,8:N2} MB' -f ($b / 1048576.0)) }
    if ($b -ge 1024)    { return ('{0,8:N2} KB' -f ($b / 1024.0)) }
    return ('{0,8:N0} B ' -f $b)
}

function Measure-ItemInfo([string]$relPath) {
    $full = Join-Path $root $relPath
    if (-not (Test-Path -LiteralPath $full)) {
        return [PSCustomObject]@{ Exists=$false; Files=0; Bytes=0L }
    }
    $it = Get-Item -LiteralPath $full -Force
    if ($it.PSIsContainer) {
        $files = @(Get-ChildItem -LiteralPath $full -Recurse -File -Force)
        $sum = 0L
        foreach ($f in $files) { $sum += $f.Length }
        return [PSCustomObject]@{ Exists=$true; Files=$files.Count; Bytes=$sum }
    } else {
        return [PSCustomObject]@{ Exists=$true; Files=1; Bytes=[int64]$it.Length }
    }
}

$logLines = New-Object System.Collections.Generic.List[string]
function Emit-Line([string]$txt, [string]$color = '') {
    if ($color -ne '') {
        Write-Host $txt -ForegroundColor $color
    } else {
        Write-Host $txt
    }
    $script:logLines.Add($txt)
}

Emit-Line '==================================================================================================' 'Cyan'
Emit-Line ' [BAO CAO TELEMETRY v2.0.3] DO LUONG DUNG LUONG GHI I/O VA THOI GIAN THUC THI (setup_env.bat)' 'Yellow'
Emit-Line '==================================================================================================' 'Cyan'
Emit-Line ' 1. BANG THOI GIAN THUC THI CHI TIET TUNG BUOC (DO CHINH XAC: s / ms / us)' 'Green'
Emit-Line '+--------------------------------------------------+--------------+--------------+--------------+'
Emit-Line '| Giai doan thuc thi (Step)                        |   Giay (s)   | Mili-giay(ms)| Micro-giay(us)|'
Emit-Line '+--------------------------------------------------+--------------+--------------+--------------+'
$steps = @(
    [PSCustomObject]@{ Name='Buoc 1/6: Kiem tra & Tai .download_cache';        D=$d1 },
    [PSCustomObject]@{ Name='Buoc 2/6: Giai nen ma nguon & thu vien';          D=$d2 },
    [PSCustomObject]@{ Name='Buoc 3/6: Quy hoach third_party\ & wads\';        D=$d3 },
    [PSCustomObject]@{ Name='Buoc 4/6: Bung Makefile.win, Geany & MkDocs/Lychee'; D=$d4 },
    [PSCustomObject]@{ Name='Buoc 5/6: Dang ky 3 duong dan User PATH v2.0.3';  D=$d5 },
    [PSCustomObject]@{ Name='Buoc 6/6: Bien dich da luong (-j + ccache)';      D=$d6 }
)
foreach ($st in $steps) {
    Emit-Line ('| {0,-48} | {1,10:N3} s | {2,9:N2} ms | {3,9:N0} us |' -f $st.Name, $st.D.Sec, $st.D.Ms, $st.D.Us)
}
Emit-Line '+--------------------------------------------------+--------------+--------------+--------------+'
Emit-Line ('| TONG THOI GIAN THUC THI TOAN BO 6 BUOC           | {0,10:N3} s | {1,9:N2} ms | {2,9:N0} us |' -f $totSec, $totMs, $totUs) 'Yellow'
Emit-Line '+--------------------------------------------------+--------------+--------------+--------------+'
Emit-Line ''
Emit-Line ' 2. BANG DO LUONG DUNG LUONG GHI MOI (WRITTEN) VS TAI SU DUNG (REUSED - 0B WRITE)' 'Green'
Emit-Line '+-------------------+----------------------------------+----------+------------------+--------------+'
Emit-Line '| Phan loai I/O     | Ten File / Thu muc (v2.0.3)      | So File  | Dung luong(Bytes)| Quy doi      |'
Emit-Line '+-------------------+----------------------------------+----------+------------------+--------------+'
$items = @(
    [PSCustomObject]@{ Path='doomgeneric-master';                  Label='doomgeneric-master\ (Source C)';     Mode='WRITTEN'   },
    [PSCustomObject]@{ Path='wads\DOOM1.WAD';                      Label='wads\DOOM1.WAD (Game IWAD Data)';    Mode='WAD'       },
    [PSCustomObject]@{ Path='third_party\SDL2';                    Label='third_party\SDL2\ (Lib + DLL)';      Mode='TP_SDL'    },
    [PSCustomObject]@{ Path='third_party\SDL2_mixer';              Label='third_party\SDL2_mixer\ (Lib+DLL)';  Mode='TP_MIX'    },
    [PSCustomObject]@{ Path='build';                               Label='build\ (84 Object .o files)';        Mode='WRITTEN'   },
    [PSCustomObject]@{ Path='EduDoom-Ass.exe';                     Label='EduDoom-Ass.exe (Binary)';           Mode='WRITTEN'   },
    [PSCustomObject]@{ Path='Custom build Makefile\Makefile.win';  Label='Custom build Makefile\Makefile.win'; Mode='WRITTEN'   },
    [PSCustomObject]@{ Path='EduDoom-Ass.geany';                   Label='EduDoom-Ass.geany (Project 10 o)';   Mode='WRITTEN'   },
    [PSCustomObject]@{ Path='lychee.toml';                         Label='lychee.toml (Lychee Test Config)';   Mode='WRITTEN'   },
    [PSCustomObject]@{ Path='.savegame';                           Label='.savegame\ (Save .dsg - Bao ve)';    Mode='SAVEGAME'  },
    [PSCustomObject]@{ Path='.ccache';                             Label='.ccache\ (Compiler Object Cache)';   Mode='CCACHE'    },
    [PSCustomObject]@{ Path='mingw64';                             Label='mingw64\ (WinLibs GCC 16.2 Pure)';   Mode='MINGW'     },
    [PSCustomObject]@{ Path='.download_cache';                     Label='.download_cache\ (Goi nen goc)';     Mode='DLCACHE'   },
    [PSCustomObject]@{ Path='README.md';                           Label='README.md (Tai lieu goc v2.0.3)';    Mode='ROOT_RM'   },
    [PSCustomObject]@{ Path='assets\document';                     Label='assets\document\ (.md + build_info)';Mode='PROTECT'   }
)
$writtenBytes = 0L; $writtenFiles = 0
$reusedBytes  = 0L; $reusedFiles  = 0
foreach ($it in $items) {
    $m = Measure-ItemInfo $it.Path
    if (-not $m.Exists) { continue }
    $tag = '[GHI MOI]'
    $isWritten = $true
    if ($it.Mode -eq 'MINGW') {
        if ($env:STEP2_EXTRACTED_MINGW -eq '1') { $tag = '[GHI MOI (COLD)]'; $isWritten = $true }
        else { $tag = '[TAI SU DUNG]'; $isWritten = $false }
    } elseif ($it.Mode -eq 'TP_SDL') {
        if ($env:STEP3_EXTRACTED_SDL2 -eq '1') { $tag = '[GHI MOI]'; $isWritten = $true }
        else { $tag = '[TAI SU DUNG]'; $isWritten = $false }
    } elseif ($it.Mode -eq 'TP_MIX') {
        if ($env:STEP3_EXTRACTED_MIXER -eq '1') { $tag = '[GHI MOI]'; $isWritten = $true }
        else { $tag = '[TAI SU DUNG]'; $isWritten = $false }
    } elseif ($it.Mode -eq 'WAD') {
        if ($env:STEP3_COPIED_WAD -eq '1') { $tag = '[GHI MOI]'; $isWritten = $true }
        else { $tag = '[TAI SU DUNG]'; $isWritten = $false }
    } elseif ($it.Mode -eq 'SAVEGAME') {
        if ($env:PRE_SAVEGAME_EXIST -eq '1') { $tag = '[BAO VE .DSG]'; $isWritten = $false }
        else { $tag = '[KHOI TAO RONG]'; $isWritten = $true }
    } elseif ($it.Mode -eq 'DLCACHE') {
        if ($env:STEP1_DOWNLOADED -eq '1') { $tag = '[TAI MANG MOI]'; $isWritten = $true }
        else { $tag = '[CACHE HIT 0B]'; $isWritten = $false }
    } elseif ($it.Mode -eq 'CCACHE') {
        $tag = '[CACHE/METADATA]'
        $isWritten = $false
    } elseif ($it.Mode -eq 'ROOT_RM') {
        if ($env:WRITE_ROOT_README -eq '1') { $tag = '[GHI MOI]'; $isWritten = $true }
        else { $tag = '[GIU NGUYEN 0B]'; $isWritten = $false }
    } elseif ($it.Mode -eq 'PROTECT') {
        $tag = '[BAO VE 0B GHI]'
        $isWritten = $false
    }
    if ($isWritten) { $writtenBytes += $m.Bytes; $writtenFiles += $m.Files }
    else            { $reusedBytes  += $m.Bytes; $reusedFiles  += $m.Files }
    Emit-Line ('| {0,-17} | {1,-32} | {2,8:N0} | {3,16:N0} | {4,12} |' -f $tag, $it.Label, $m.Files, $m.Bytes, (Fmt-Size $m.Bytes))
}
Emit-Line '+-------------------+----------------------------------+----------+------------------+--------------+'
Emit-Line ('| TONG DUNG LUONG GHI MOI LEN DIA LAN NAY (WRITTEN)               | {0,8:N0} | {1,16:N0} | {2,12} |' -f $writtenFiles, $writtenBytes, (Fmt-Size $writtenBytes)) 'Yellow'
Emit-Line ('| TONG DUNG LUONG TAI SU DUNG / BAO TOAN (0 BYTE WRITE)           | {0,8:N0} | {1,16:N0} | {2,12} |' -f $reusedFiles, $reusedBytes, (Fmt-Size $reusedBytes)) 'Cyan'
Emit-Line ('| TONG DUNG LUONG TOAN DU AN HIEN TAI (TOTAL FOOTPRINT)           | {0,8:N0} | {1,16:N0} | {2,12} |' -f ($writtenFiles + $reusedFiles), ($writtenBytes + $reusedBytes), (Fmt-Size ($writtenBytes + $reusedBytes))) 'Green'
Emit-Line '+-----------------------------------------------------------------+----------+------------------+--------------+'

# --- 3. QUET DANH SACH FILE .C / .CPP / .H / .HPP VA SO SANH VOI MANIFEST ---
$srcDir = Join-Path $root 'doomgeneric-master\doomgeneric'
$cFiles   = @()
$cppFiles = @()
$hFiles   = @()
$hppFiles = @()
if (Test-Path -LiteralPath $srcDir) {
    $cFiles   = @(Get-ChildItem -LiteralPath $srcDir -Filter '*.c'   -File | Select-Object -ExpandProperty Name | Sort-Object)
    $cppFiles = @(Get-ChildItem -LiteralPath $srcDir -Filter '*.cpp' -File | Select-Object -ExpandProperty Name | Sort-Object)
    $hFiles   = @(Get-ChildItem -LiteralPath $srcDir -Filter '*.h'   -File | Select-Object -ExpandProperty Name | Sort-Object)
    $hppFiles = @(Get-ChildItem -LiteralPath $srcDir -Filter '*.hpp' -File | Select-Object -ExpandProperty Name | Sort-Object)
}
$curAll = @($cFiles + $cppFiles + $hFiles + $hppFiles | Sort-Object)
$manifestFile = Join-Path $root '.ccache\source_manifest.txt'
$addedList   = 'Khong co (0 file)'
$removedList = 'Khong co (0 file)'
if (Test-Path -LiteralPath $manifestFile) {
    $prevAll = @(Get-Content -LiteralPath $manifestFile -Encoding UTF8 | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $added   = @($curAll  | Where-Object { $prevAll -notcontains $_ })
    $removed = @($prevAll | Where-Object { $curAll  -notcontains $_ })
    if ($added.Count -gt 0)   { $addedList   = ('+' + $added.Count + ' file: ' + ($added -join ', ')) }
    if ($removed.Count -gt 0) { $removedList = ('-' + $removed.Count + ' file: ' + ($removed -join ', ')) }
} else {
    $addedList = ('Khoi tao danh sach goc (' + $curAll.Count + ' file)')
}
if ($curAll.Count -gt 0) {
    Set-Content -LiteralPath $manifestFile -Value $curAll -Encoding UTF8
}

# --- 4. CAP NHAT FILE build_info.txt (KHONG TU TAO HOAC GHI DE assets\document\README.md CON) ---
$docDir = Join-Path $root 'assets\document'
if (-not (Test-Path -LiteralPath $docDir)) { New-Item -ItemType Directory -Path $docDir -Force | Out-Null }
$buildInfoPath = Join-Path $docDir 'build_info.txt'

$nowDt  = Get-Date
$tsFull = $nowDt.ToString('yyyy-MM-dd HH:mm:ss.fff')
$tsVn   = $nowDt.ToString('dd/MM/yyyy - HH:mm:ss.fff')
$runMode = 'WARM/HOT SETUP (Tai su dung mingw64 + third_party + ccache)'
if ($env:STEP2_EXTRACTED_MINGW -eq '1') {
    $runMode = 'COLD SETUP (Giai nen Toolchain + Build)'
}
$threads = $env:NUMBER_OF_PROCESSORS
if ($env:CPU_THREADS) { $threads = $env:CPU_THREADS }
$readmeStatus = 'GIU NGUYEN README.MD GOC (Phuc vu debug)'
if ($env:WRITE_ROOT_README -eq '1') {
    $readmeStatus = 'DA GHI MOI / CAP NHAT README.MD GOC v2.0.3'
}

$entryBlock = New-Object System.Collections.Generic.List[string]
$entryBlock.Add('')
$entryBlock.Add('##################################################################################################')
$entryBlock.Add(('>>>>>>>>>>>>>>>>>> [BEGIN_BLOCK | v2.0.3 | SETUP_ENV.BAT | {0}] >>>>>>>>>>>>>>>>>>' -f $tsFull))
$entryBlock.Add('##################################################################################################')
$entryBlock.Add(('  * Ngay gio thuc thi chi tiet : {0} ({1})' -f $tsFull, $tsVn))
$entryBlock.Add('  * Phien ban & Kich ban       : EduDoom-Ass v2.0.3 | setup_env.bat')
$entryBlock.Add(('  * Trang thai khoi tao        : {0}' -f $runMode))
$entryBlock.Add(('  * Trang thai README.md goc   : {0}' -f $readmeStatus))
$entryBlock.Add(('  * So luong thuc thi (-jN)    : -j{0} ({0} luong CPU)' -f $threads))
$entryBlock.Add(('  * Thong ke file ma nguon     : Tong {0} file (.c: {1} | .cpp: {2} | .h: {3} | .hpp: {4})' -f $curAll.Count, $cFiles.Count, $cppFiles.Count, $hFiles.Count, $hppFiles.Count))
$entryBlock.Add(('    - File .c/.cpp/.h THEM MOI : {0}' -f $addedList))
$entryBlock.Add(('    - File .c/.cpp/.h BI GO BO : {0}' -f $removedList))
$entryBlock.Add(('  * Tom tat ket qua            : Tong thoi gian Setup = {0:N3} s ({1:N2} ms) | Ghi moi = {2} ({3} files) | Tai su dung = {4} ({5} files)' -f $totSec, $totMs, (Fmt-Size $writtenBytes), $writtenFiles, (Fmt-Size $reusedBytes), $reusedFiles))
$entryBlock.Add('--------------------------------------------------------------------------------------------------')
foreach ($l in $logLines) { $entryBlock.Add($l) }
$entryBlock.Add('##################################################################################################')
$entryBlock.Add(('<<<<<<<<<<<<<<<<<< [END_BLOCK   | v2.0.3 | SETUP_ENV.BAT | {0}] <<<<<<<<<<<<<<<<<<' -f $tsFull))
$entryBlock.Add('##################################################################################################')

$headerBlock = @(
    '==================================================================================================',
    '          HO SO CAU HINH MAY TINH, TOOLCHAIN & NHAT KY DO LUONG BUILD (build_info.txt)            ',
    '==================================================================================================',
    '  * Du an               : EduDoom-Ass (Kien truc v2.0.3+ - Tach third_party\, wads\ & Hoa tan Clean)',
    '  * Lien ket tai lieu   : Duoc tham chieu truc tiep tu assets\document\README.md & ..\..\README.md',
    '  * Thuat toan ghi Log  : GHI DAO NGUOC THEO THOI GIAN (LIFO - NEWEST ON TOP):',
    '                          - Phan I (Phan cung) & Phan II (Toolchain) duoc CO DINH 100% o tren dau.',
    '                          - Moi lan chay setup_env.bat hoac clean_all_except_setup.bat se tu dong',
    '                            chen khoi BEGIN_BLOCK ... END_BLOCK MOI NHAT len ngay sat duoi Phan II,',
    '                            va day cac khoi nhat ky cu hon xuong phia duoi.',
    '                          - Neu mot lan chay thu nghiem chua ung y, ban chi can to den va xoa',
    '                            khoi BEGIN_BLOCK ... END_BLOCK do roi chay lai script.',
    '==================================================================================================',
    '',
    '--------------------------------------------------------------------------------------------------',
    ' [PHAN I] CAU HINH PHAN CUNG MAY TINH CO DINH LUC BUILD (PC HARDWARE & OS BASELINE)',
    '--------------------------------------------------------------------------------------------------',
    ('  - Ten may (Hostname)  : DESKTOP-VKTT723 (Current: {0})' -f $env:COMPUTERNAME),
    '  - He dieu hanh (OS)   : Windows 10 Pro 64-bit (10.0.19045 / Windows NT)',
    '  - Bo mach chu (Board) : ASUS PRIME B550M-A WIFI II (UEFI BIOS 16 MB Flash @ 0xFF000000)',
    '  - Vi xu ly (CPU)      : AMD Ryzen 5 5500X3D (Vermeer-X Zen 3, 6 Nhan / 12 Luong, 3.0 - 4.0 GHz)',
    '  - Bo nho dem Cache    : L1D 6x32 KB + L1I 6x32 KB (8-way) | L2 6x512 KB (3 MB, 8-way) | L3 3D V-Cache 96 MB (16-way)',
    '  - Bo nho RAM          : 16 GB DDR4 Dual-Channel @ 3000 MT/s (16-18-18-38, 2x8 GB DIMM_A2 & DIMM_B2)',
    '',
    '--------------------------------------------------------------------------------------------------',
    ' [PHAN II] CAU HINH TOOLCHAIN, TRINH BIEN DICH & CO LIEN KET DU AN (BUILD CONFIGURATION)',
    '--------------------------------------------------------------------------------------------------',
    '  - Goi Toolchain       : WinLibs Standalone MinGW-w64 (x86_64-posix-seh-gcc-16.2.0-llvm-23.1.3-mingw-w64ucrt-14.0.0-r3)',
    '  - Compiler (C/C++)    : .\mingw64\bin\gcc.exe & .\mingw64\bin\g++.exe (GCC 16.2.0, 64-bit UCRT)',
    '  - Compiler Cache      : .\mingw64\bin\ccache.exe (Bam BLAKE3 + Nen Zstandard, kho luu .ccache\)',
    '  - Linker              : .\mingw64\bin\gcc.exe -> ld.exe (GNU ld, -fno-use-linker-plugin)',
    '  - Build System (Make) : .\mingw64\bin\mingw32-make.exe (GNU Make 4.4.1, SHELL=cmd.exe, Custom build Makefile\Makefile.win)',
    '  - Debugger            : .\mingw64\bin\gdb.exe (GNU GDB di kem WinLibs MinGW64)',
    '  - Thu vien third_party: .\third_party\SDL2 (v2.0.20) + .\third_party\SDL2_mixer (v2.8.1) [Tach khoi mingw64]',
    '  - Du lieu Game IWAD   : .\wads\DOOM1.WAD (DOOM Shareware v1.9, nap tu dong qua main() & -iwad)',
    '  - Co Compiler (CFLAGS): -I"./mingw64/include" -I"./mingw64/x86_64-w64-mingw32/include" -I"./third_party/SDL2/include" -I"./third_party/SDL2_mixer/include" -O2 -pipe -Wno-implicit-function-declaration -Wno-implicit-int',
    '  - Co Linker (LIBS)    : -L"./mingw64/lib" -L"./mingw64/x86_64-w64-mingw32/lib" -L"./third_party/SDL2/lib" -L"./third_party/SDL2_mixer/lib" -static-libgcc -lmingw32 -lSDL2main -lSDL2 -lSDL2_mixer -lm -lwinmm -lgdi32 -luser32',
    '==================================================================================================',
    ''
)

$newBlockText = ($entryBlock -join "`r`n").Trim()
$allBlocks = New-Object System.Collections.Generic.List[PSCustomObject]
$allBlocks.Add([PSCustomObject]@{ Ts = $tsFull; Text = $newBlockText })

if (Test-Path -LiteralPath $buildInfoPath) {
    $rawExisting = [System.IO.File]::ReadAllText($buildInfoPath, [System.Text.Encoding]::UTF8)
    $blkPattern = '(?s)#{50,}\r?\n>>>>>>>>>>>>>>>>>> \[BEGIN_BLOCK \| [^\r\n]+\r?\n.*?\r?\n<<<<<<<<<<<<<<<<<< \[END_BLOCK[^\r\n]+\r?\n#{50,}'
    $blkMatches = [regex]::Matches($rawExisting, $blkPattern)
    foreach ($m in $blkMatches) {
        $blkTxt = $m.Value.Trim()
        $tsM = [regex]::Match($blkTxt, '\[BEGIN_BLOCK \| [^|]+\| [^|]+\| ([0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{3})\]')
        $bTs = if ($tsM.Success) { $tsM.Groups[1].Value } else { '0000-00-00 00:00:00.000' }
        $allBlocks.Add([PSCustomObject]@{ Ts = $bTs; Text = $blkTxt })
    }
}

# Sap xep toan bo cac khoi theo nhan thoi gian giam dan (LIFO: MOI NHAT NAM NGAY TREN DAU, cu hon day xuong duoi)
$sortedBlocks = @($allBlocks | Sort-Object -Property Ts -Descending)

$finalOut = New-Object System.Collections.Generic.List[string]
foreach ($hl in $headerBlock) { $finalOut.Add($hl) }
$finalOut.Add(':: ==================================================================================================')
$finalOut.Add(':: [DANH SACH NHAT KY DO LUONG THEO THOI GIAN - THU TU LIFO: BAN GHI MOI NHAT NAM NGAY TREN DAU]')
$finalOut.Add((':: (Tong so khoi nhat ky hien co: {0} khoi | Cap nhat moi nhat luc: {1})' -f $sortedBlocks.Count, $tsFull))
$finalOut.Add(':: ==================================================================================================')
foreach ($sbItem in $sortedBlocks) {
    $finalOut.Add('')
    $finalOut.Add($sbItem.Text)
}
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($buildInfoPath, $finalOut, $utf8NoBom)
Write-Host ''
Write-Host ('  -> [AUTO-LOG] Da chen khoi du lieu Setup MOI NHAT ({0}) len DAU danh sach Log trong: assets\document\build_info.txt' -f $tsFull) -ForegroundColor Magenta
