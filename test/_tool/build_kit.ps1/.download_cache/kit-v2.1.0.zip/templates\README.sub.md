# Bản đồ Tài liệu Kỹ thuật (EduDoom-Ass)

> **Phiên bản:** {{VERSION}} | **Cập nhật lần cuối:** {{DATE}}

Chào mừng bạn đến với kho tài liệu của dự án. Dưới đây là danh sách các tài liệu hiện có trong thư mục này:

{{MAP}}

---
*Ghi chú: Danh sách này được tự động tạo bởi `install_docs.ps1` dựa trên các file `NN_*.md` thực tế đang có trong thư mục. Nếu bạn thêm file mới, hãy chạy lại `setup_env.bat` để cập nhật bản đồ.*