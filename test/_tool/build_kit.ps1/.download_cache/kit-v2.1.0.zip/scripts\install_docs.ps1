﻿# ============================================================================
# EduDoom-Ass Kit - Document Installer (v2.1.0 - Grok Architecture)
# ============================================================================
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

$root = $env:PROJECT_DIR
if ([string]::IsNullOrWhiteSpace($root)) { $root = (Get-Location).Path }
$kitDir = $env:KIT_DIR
if ([string]::IsNullOrWhiteSpace($kitDir)) { $kitDir = Join-Path $root '.download_cache\kit-v2.1.0' }

$verFolder = Split-Path -Leaf $root
$parentDir = Split-Path -Parent $root
$docDir = Join-Path $root 'assets\document'
$templateDir = Join-Path $kitDir 'templates'

if (-not (Test-Path -LiteralPath $docDir)) { New-Item -ItemType Directory -Path $docDir -Force | Out-Null }

function Write-Utf8($path, $content) {
    if (Test-Path $path) { (Get-Item $path -Force).Attributes = 'Normal' }
    [System.IO.File]::WriteAllText($path, $content, $utf8NoBom)
}

Write-Host "  - [DOCS] Dang cap nhat tai lieu cho $verFolder..."

# 2. Copy QUY_DINH_TAI_LIEU.md
$quyDinhSrc = Join-Path $templateDir 'QUY_DINH_TAI_LIEU.md'
$quyDinhDst = Join-Path $root 'QUY_DINH_TAI_LIEU.md'
if (Test-Path $quyDinhSrc) { Copy-Item -Path $quyDinhSrc -Destination $quyDinhDst -Force }

# 3. Quét các file NN_*.md
$docFiles = Get-ChildItem -LiteralPath $docDir -Filter "*.md" | Where-Object { $_.Name -match '^\d{2}_.+\.md$' } | Sort-Object Name

$docListSub = @()
$docListRoot = @()
$navLines = @("nav:", "  - Trang chủ: README.md", "  - Quy định tài liệu: QUY_DINH_TAI_LIEU.md", "  - Bản đồ tài liệu: assets/document/README.md")

foreach ($f in $docFiles) {
    # Đọc an toàn bằng .NET để không lỗi font
    $firstLine = [System.IO.File]::ReadLines($f.FullName, [System.Text.Encoding]::UTF8) | Select-Object -First 1
    $title = $f.BaseName
    if ($firstLine -match '^#\s+(.+)$') { $title = $matches[1].Trim() }
    
    # Đường dẫn cho file README con (nằm cùng thư mục)
    $docListSub += "- [$title](./$($f.Name))"
    # Đường dẫn cho file README gốc (nằm ở thư mục cha)
    $docListRoot += "- [$title](./assets/document/$($f.Name))"
    # Đường dẫn cho Nav của mkdocs.yml
    $navLines += "  - ${title}: assets/document/$($f.Name)"
}

$mapContentSub = $docListSub -join "`r`n"
$mapContentRoot = $docListRoot -join "`r`n"
if ([string]::IsNullOrWhiteSpace($mapContentSub)) { $mapContentSub = "*Chưa có tài liệu nào.*"; $mapContentRoot = $mapContentSub }

# 4. Dựng lại README.md con
$readmeSubSrc = Join-Path $templateDir 'README.sub.md'
if (Test-Path $readmeSubSrc) {
    $subContent = Get-Content -LiteralPath $readmeSubSrc -Raw -Encoding UTF8
    $subContent = $subContent.Replace('{{VERSION}}', $verFolder).Replace('{{DATE}}', (Get-Date -Format 'yyyy-MM-dd')).Replace('{{MAP}}', $mapContentSub)
    Write-Utf8 (Join-Path $docDir 'README.md') $subContent
}

# 5. Sinh README.md gốc
$readmeRootSrc = Join-Path $templateDir 'README.root.md'
$readmeRootDst = Join-Path $root 'README.md'
if (Test-Path $readmeRootSrc) {
    $writeRoot = $true
    if (Test-Path $readmeRootDst) {
        $ans = Read-Host "  [?] File README.md goc da ton tai. Ghi de? (Y/N) [Mac dinh: Y]"
        if ($ans -match '^[Nn]') { $writeRoot = $false }
    }
    if ($writeRoot) {
        $rootContent = Get-Content -LiteralPath $readmeRootSrc -Raw -Encoding UTF8
        $rootContent = $rootContent.Replace('{{VERSION}}', $verFolder).Replace('{{DATE}}', (Get-Date -Format 'yyyy-MM-dd')).Replace('{{AUTO_DOC_BLOCK}}', $mapContentRoot)
        Write-Utf8 $readmeRootDst $rootContent
    }
}

# 6. Vá mkdocs.yml
$mkdocsFile = Join-Path $parentDir 'mkdocs.yml'
$mkdocsBase = Join-Path $templateDir 'mkdocs.base.yml'

if (-not (Test-Path $mkdocsFile) -and (Test-Path $mkdocsBase)) {
    Copy-Item -Path $mkdocsBase -Destination $mkdocsFile -Force
}

if (Test-Path $mkdocsFile) {
    $mkdocsText = Get-Content -LiteralPath $mkdocsFile -Raw -Encoding UTF8
    if ($mkdocsText -match '(?m)^docs_dir:.*$') {
        $mkdocsText = $mkdocsText -replace '(?m)^docs_dir:.*$', "docs_dir: $verFolder"
    } else {
        $mkdocsText = "docs_dir: $verFolder`r`n" + $mkdocsText
    }
    $navBlock = $navLines -join "`r`n"
    if ($mkdocsText -match '(?s)(?m)^nav:.*?(?=^\S|\Z)') {
        $mkdocsText = $mkdocsText -replace '(?s)(?m)^nav:.*?(?=^\S|\Z)', "$navBlock`r`n"
    } else {
        $mkdocsText = $mkdocsText.TrimEnd() + "`r`n`r`n$navBlock`r`n"
    }
    Write-Utf8 $mkdocsFile $mkdocsText
}

Write-Host "  - [DOCS] Da cap nhat xong README.md (con & goc) va mkdocs.yml." -ForegroundColor Green